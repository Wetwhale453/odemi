
/*
document.getElementById("menuButton").onclick = function () {
    location.href = "www.youtube.com";
};
*/